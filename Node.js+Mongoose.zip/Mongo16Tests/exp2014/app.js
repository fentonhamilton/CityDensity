var express = require('express');
var mongoose = require('mongoose');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var http = require('http');
var json2csv = require('json2csv');
var fs = require('fs');
var request = require('request');
var jsontocsv = require('jsontocsv');
//print console is running 
console.log('running!');
var app = express();

// view engine setup 
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hjs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico'))); 
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//mongoose.connect('mongodb://localhost/Smart_City'); 
//connecting to local host 127.0.0.1:27017 and to the database Smart_City
//note when trying to access a database, careful on the capital letters
//and new databases are created given any name if not already in MongoDB
mongoose.connect('mongodb://localhost/Smart_City');
 
var db = mongoose.connection;
 
db.on('error', function (err) {
console.log('connection error', err);
});
db.once('open', function () {
console.log('connected.');
});

//schema for the tube associations collection (table)
var Tube_associations_Schema = new mongoose.Schema({
	GridNo : Number,
	Zone : Number,
	Station : String,
	Latitude : Number,
	Longtitude : Number
}, {collection:'Tube_associations'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var Tube_associations = mongoose.model('Tube_associations', Tube_associations_Schema, Tube_associations);

//schema for boroughpopulations.csv
var BoroughPopulations_Schema = new mongoose.Schema({
	"Borough" : String,"Year1" : Number,"Year2" : Number, "Year3" : Number,"Year4" : Number, "Year5" : Number, "Year6" : Number, "Year7" : Number, "Year8" : Number, "Year9" : Number, "Year10" : Number, "Year11" : Number, "Year12" : Number, "Year13" : Number, "Year14" : Number, "Year15" : Number, "Year16" : Number, "Year17" : Number, "Year18" : Number, "Year19" : Number, "Year21" : Number, "Year22" : Number, "Year23" : Number, "Year24" : Number, "Year25" : Number, "Year26" : Number, "Year27" : Number, "Year28" : Number, "Year29" : Number, "Year30" : Number, "Year31" : Number, "Year31" : Number
	
}, {collection:'BoroughPopPredics'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var BoroughPopPredics = mongoose.model('BoroughPopPredics', BoroughPopulations_Schema, BoroughPopPredics );


//schema for BradfordStaticPop.csv
var BradfordStaticPop_Schema = new mongoose.Schema({
	"CellID" : Number, 
	"Population" : Number, 
	"CellID Within Borough" : String //string due to null values
	}, {collection:'BradfordStaticPop'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var BradfordStaticPop = mongoose.model('BradfordStaticPop', BradfordStaticPop_Schema, BradfordStaticPop );

//schema for LiverpoolStaticPop.csv
var LiverpoolStaticPop_Schema = new mongoose.Schema({
	"CellID" : Number, 
	"Population" : Number, 
	"CellID Within Borough" : String //string due to null values
	}, {collection:'LiverpoolStaticPop'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var LiverpoolStaticPop = mongoose.model('LiverpoolStaticPop', LiverpoolStaticPop_Schema, LiverpoolStaticPop );

//schema for LondonStaticPop.csv
var LondonStaticPop_Schema = new mongoose.Schema({
	"CellID" : Number, 
	"Population" : Number, 
	"CellID Within Borough" : String //string due to null values
	}, {collection:'LondonStaticPop'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var LondonStaticPop = mongoose.model('LondonStaticPop', LondonStaticPop_Schema, LondonStaticPop );

//schema for WiganStaticPop.csv
var WiganStaticPop_Schema = new mongoose.Schema({
	"CellID" : Number, 
	"Population" : Number, 
	"CellID Within Borough" : String //string due to null values
	}, {collection:'WiganStaticPop'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var WiganStaticPop = mongoose.model('WiganStaticPop', WiganStaticPop_Schema, WiganStaticPop );


///work poulations

//schema for Bradford_CellWorkPopulations.csv
var Bradford_CellWorkPopulations_Schema = new mongoose.Schema({
	"CellID" : Number, 
	"Population" : Number, 
	"CellID Within Borough" : String //string due to null values
	}, {collection:'Bradford_CellWorkPopulations'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var Bradford_CellWorkPopulations = mongoose.model('Bradford_CellWorkPopulations', Bradford_CellWorkPopulations_Schema, Bradford_CellWorkPopulations );

//schema for Liverpool_CellWorkPopulations.csv
var Liverpool_CellWorkPopulations_Schema = new mongoose.Schema({
	"CellID" : Number, 
	"Population" : Number, 
	"CellID Within Borough" : String //string due to null values
	}, {collection:'Liverpool_CellWorkPopulations'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var Liverpool_CellWorkPopulations = mongoose.model('Liverpool_CellWorkPopulations', Liverpool_CellWorkPopulations_Schema, Liverpool_CellWorkPopulations );

//schema for London_CellWorkPopulations.csv
var London_CellWorkPopulations_Schema = new mongoose.Schema({
	"CellID" : Number, 
	"Population" : Number, 
	"CellID Within Borough" : String //string due to null values
	}, {collection:'London_CellWorkPopulations'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var London_CellWorkPopulations = mongoose.model('London_CellWorkPopulations', London_CellWorkPopulations_Schema, London_CellWorkPopulations );

//schema for Wigan_CellWorkPopulations.csv
var Wigan_CellWorkPopulations_Schema = new mongoose.Schema({
	"CellID" : Number, 
	"Population" : Number, 
	"CellID Within Borough" : String //string due to null values
	}, {collection:'Wigan_CellWorkPopulations'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var Wigan_CellWorkPopulations = mongoose.model('Wigan_CellWorkPopulations', Wigan_CellWorkPopulations_Schema, Wigan_CellWorkPopulations );


//schema for WeekdayTubePredictions.csv
var WeekdayTubePredictions_Schema = new mongoose.Schema({
"1":Number, 	"2":Number, 	"3":Number, 	"4":Number, 	"5":Number, 	"6":Number, 	"7":Number, 	"8":Number, 	"9":Number, 	"10":Number, 	"11":Number, 	"12":Number, 	"13":Number, 	"14":Number, 	"15":Number, 	"16":Number, 	"17":Number, 	"18":Number, 	"19":Number, 	"20":Number, 	"21":Number, 	"22":Number, 	"23":Number, 	"24":Number, 	"25":Number, 	"26":Number, 	"27":Number, 	"28":Number, 	"29":Number, 	"30":Number, 	"31":Number, 	"32":Number, 	"33":Number, 	"34":Number, 	"35":Number, 	"36":Number, 	"37":Number, 	"38":Number, 	"39":Number, 	"40":Number, 	"41":Number, 	"42":Number, 	"43":Number, 	"44":Number, 	"45":Number, 	"46":Number, 	"47":Number, 	"48":Number, 	"49":Number, 	"50":Number, 	"51":Number, 	"52":Number, 	"53":Number, 	"54":Number, 	"55":Number, 	"56":Number, 	"57":Number, 	"58":Number, 	"59":Number, 	"60":Number, 	"61":Number, 	"62":Number, 	"63":Number, 	"64":Number, 	"65":Number, 	"66":Number, 	"67":Number, 	"68":Number, 	"69":Number, 	"70":Number, 	"71":Number, 	"72":Number, 	"73":Number, 	"74":Number, 	"75":Number, 	"76":Number, 	"77":Number, 	"78":Number, 	"79":Number, 	"80":Number, 	"81":Number, 	"82":Number, 	"83":Number, 	"84":Number, 	"85":Number, 	"86":Number, 	"87":Number, 	"88":Number, 	"89":Number, 	"90":Number, 	"91":Number, 	"92":Number, 	"93":Number, 	"94":Number, 	"95":Number, 	"96":Number, 	"97":Number, 	"98":Number, 	"99":Number, 	"100":Number, 	"101":Number, 	"102":Number, 	"103":Number, 	"104":Number, 	"105":Number, 	"106":Number, 	"107":Number, 	"108":Number, 	"109":Number, 	"110":Number, 	"111":Number, 	"112":Number, 	"113":Number, 	"114":Number, 	"115":Number, 	"116":Number, 	"117":Number, 	"118":Number, 	"119":Number, 	"120":Number, 	"121":Number, 	"122":Number, 	"123":Number, 	"124":Number, 	"125":Number, 	"126":Number, 	"127":Number, 	"128":Number, 	"129":Number, 	"130":Number, 	"131":Number, 	"132":Number, 	"133":Number, 	"134":Number, 	"135":Number, 	"136":Number, 	"137":Number, 	"138":Number, 	"139":Number, 	"140":Number, 	"141":Number, 	"142":Number, 	"143":Number, 	"144":Number, 	"145":Number, 	"146":Number, 	"147":Number, 	"148":Number, 	"149":Number, 	"150":Number, 	"151":Number, 	"152":Number, 	"153":Number, 	"154":Number, 	"155":Number, 	"156":Number, 	"157":Number, 	"158":Number, 	"159":Number, 	"160":Number, 	"161":Number, 	"162":Number, 	"163":Number, 	"164":Number, 	"165":Number, 	"166":Number, 	"167":Number, 	"168":Number, 	"169":Number, 	"170":Number, 	"171":Number, 	"172":Number, 	"173":Number, 	"174":Number, 	"175":Number, 	"176":Number, 	"177":Number, 	"178":Number, 	"179":Number, 	"180":Number, 	"181":Number, 	"182":Number, 	"183":Number, 	"184":Number, 	"185":Number, 	"186":Number, 	"187":Number, 	"188":Number, 	"189":Number, 	"190":Number, 	"191":Number, 	"192":Number, 	"193":Number, 	"194":Number, 	"195":Number, 	"196":Number, 	"197":Number, 	"198":Number, 	"199":Number, 	"200":Number, 	"201":Number, 	"202":Number, 	"203":Number, 	"204":Number, 	"205":Number, 	"206":Number, 	"207":Number, 	"208":Number, 	"209":Number, 	"210":Number, 	"211":Number, 	"212":Number, 	"213":Number, 	"214":Number, 	"215":Number, 	"216":Number, 	"217":Number, 	"218":Number, 	"219":Number, 	"220":Number, 	"221":Number, 	"222":Number, 	"223":Number, 	"224":Number, 	"225":Number, 	"226":Number, 	"227":Number, 	"228":Number, 	"229":Number, 	"230":Number, 	"231":Number, 	"232":Number, 	"233":Number, 	"234":Number, 	"235":Number, 	"236":Number, 	"237":Number, 	"238":Number, 	"239":Number, 	"240":Number, 	"241":Number, 	"242":Number, 	"243":Number, 	"244":Number, 	"245":Number, 	"246":Number, 	"247":Number, 	"248":Number, 	"249":Number, 	"250":Number, 	"251":Number, 	"252":Number, 	"253":Number, 	"254":Number, 	"255":Number, 	"256":Number, 	"257":Number, 	"258":Number, 	"259":Number, 	"260":Number, 	"261":Number, 	"262":Number, 	"263":Number, 	"264":Number, 	"265":Number, 	"266":Number
}, {collection:'WeekdayTubePredictions'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var WeekdayTubePredictions = mongoose.model('WeekdayTubePredictions', WeekdayTubePredictions_Schema, WeekdayTubePredictions );

//schema for WeekendTubePredictions.csv
var WeekendTubePredictions_Schema = new mongoose.Schema({
"1":Number, 	"2":Number, 	"3":Number, 	"4":Number, 	"5":Number, 	"6":Number, 	"7":Number, 	"8":Number, 	"9":Number, 	"10":Number, 	"11":Number, 	"12":Number, 	"13":Number, 	"14":Number, 	"15":Number, 	"16":Number, 	"17":Number, 	"18":Number, 	"19":Number, 	"20":Number, 	"21":Number, 	"22":Number, 	"23":Number, 	"24":Number, 	"25":Number, 	"26":Number, 	"27":Number, 	"28":Number, 	"29":Number, 	"30":Number, 	"31":Number, 	"32":Number, 	"33":Number, 	"34":Number, 	"35":Number, 	"36":Number, 	"37":Number, 	"38":Number, 	"39":Number, 	"40":Number, 	"41":Number, 	"42":Number, 	"43":Number, 	"44":Number, 	"45":Number, 	"46":Number, 	"47":Number, 	"48":Number, 	"49":Number, 	"50":Number, 	"51":Number, 	"52":Number, 	"53":Number, 	"54":Number, 	"55":Number, 	"56":Number, 	"57":Number, 	"58":Number, 	"59":Number, 	"60":Number, 	"61":Number, 	"62":Number, 	"63":Number, 	"64":Number, 	"65":Number, 	"66":Number, 	"67":Number, 	"68":Number, 	"69":Number, 	"70":Number, 	"71":Number, 	"72":Number, 	"73":Number, 	"74":Number, 	"75":Number, 	"76":Number, 	"77":Number, 	"78":Number, 	"79":Number, 	"80":Number, 	"81":Number, 	"82":Number, 	"83":Number, 	"84":Number, 	"85":Number, 	"86":Number, 	"87":Number, 	"88":Number, 	"89":Number, 	"90":Number, 	"91":Number, 	"92":Number, 	"93":Number, 	"94":Number, 	"95":Number, 	"96":Number, 	"97":Number, 	"98":Number, 	"99":Number, 	"100":Number, 	"101":Number, 	"102":Number, 	"103":Number, 	"104":Number, 	"105":Number, 	"106":Number, 	"107":Number, 	"108":Number, 	"109":Number, 	"110":Number, 	"111":Number, 	"112":Number, 	"113":Number, 	"114":Number, 	"115":Number, 	"116":Number, 	"117":Number, 	"118":Number, 	"119":Number, 	"120":Number, 	"121":Number, 	"122":Number, 	"123":Number, 	"124":Number, 	"125":Number, 	"126":Number, 	"127":Number, 	"128":Number, 	"129":Number, 	"130":Number, 	"131":Number, 	"132":Number, 	"133":Number, 	"134":Number, 	"135":Number, 	"136":Number, 	"137":Number, 	"138":Number, 	"139":Number, 	"140":Number, 	"141":Number, 	"142":Number, 	"143":Number, 	"144":Number, 	"145":Number, 	"146":Number, 	"147":Number, 	"148":Number, 	"149":Number, 	"150":Number, 	"151":Number, 	"152":Number, 	"153":Number, 	"154":Number, 	"155":Number, 	"156":Number, 	"157":Number, 	"158":Number, 	"159":Number, 	"160":Number, 	"161":Number, 	"162":Number, 	"163":Number, 	"164":Number, 	"165":Number, 	"166":Number, 	"167":Number, 	"168":Number, 	"169":Number, 	"170":Number, 	"171":Number, 	"172":Number, 	"173":Number, 	"174":Number, 	"175":Number, 	"176":Number, 	"177":Number, 	"178":Number, 	"179":Number, 	"180":Number, 	"181":Number, 	"182":Number, 	"183":Number, 	"184":Number, 	"185":Number, 	"186":Number, 	"187":Number, 	"188":Number, 	"189":Number, 	"190":Number, 	"191":Number, 	"192":Number, 	"193":Number, 	"194":Number, 	"195":Number, 	"196":Number, 	"197":Number, 	"198":Number, 	"199":Number, 	"200":Number, 	"201":Number, 	"202":Number, 	"203":Number, 	"204":Number, 	"205":Number, 	"206":Number, 	"207":Number, 	"208":Number, 	"209":Number, 	"210":Number, 	"211":Number, 	"212":Number, 	"213":Number, 	"214":Number, 	"215":Number, 	"216":Number, 	"217":Number, 	"218":Number, 	"219":Number, 	"220":Number, 	"221":Number, 	"222":Number, 	"223":Number, 	"224":Number, 	"225":Number, 	"226":Number, 	"227":Number, 	"228":Number, 	"229":Number, 	"230":Number, 	"231":Number, 	"232":Number, 	"233":Number, 	"234":Number, 	"235":Number, 	"236":Number, 	"237":Number, 	"238":Number, 	"239":Number, 	"240":Number, 	"241":Number, 	"242":Number, 	"243":Number, 	"244":Number, 	"245":Number, 	"246":Number, 	"247":Number, 	"248":Number, 	"249":Number, 	"250":Number, 	"251":Number, 	"252":Number, 	"253":Number, 	"254":Number, 	"255":Number, 	"256":Number, 	"257":Number, 	"258":Number, 	"259":Number, 	"260":Number, 	"261":Number, 	"262":Number, 	"263":Number, 	"264":Number, 	"265":Number, 	"266":Number
}, {collection:'WeekendTubePredictions'}); ///this is important in order to select the correct collection and not create a new one by mistake. 

var WeekendTubePredictions = mongoose.model('WeekendTubePredictions', WeekendTubePredictions_Schema, WeekendTubePredictions );

//Allows retrival request from client
app.use(function (req, res, next) {

    // Website you wish to allow to connect
        res.setHeader('Access-Control-Allow-Origin', '*');

//  // Request methods you wish to allow
     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

//  // Request headers you wish to allow
     res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');

//     Set to true if you need the website to include cookies in the requests sent
//     to the API (e.g. in case you use sessions)
     res.setHeader('Access-Control-Allow-Credentials', true);
    // Pass to next layer of middleware
    next();
});




var basicAuth = require('basic-auth');

var auth = function (req, res, next) {
	res.setHeader('Access-Control-Allow-Credentials', true);
  function unauthorized(res) {
    res.set('WWW-Authenticate', 'Basic realm=Authorization Required');
    return res.send(401);
  };

  var user = basicAuth(req);

  if (!user || !user.name || !user.pass) {
    return unauthorized(res);
  };

  if (user.name === '&7t){kPK;&4y8[G/' && user.pass === 'Mb7NqFU_)VUAUAf7') { 
    return next();
  } else {
	  	  console.log("Attempted access failed using User Name : '" + user.name + "' and Password : '" + user.pass + "'");
    return unauthorized(res);
  };
};


app.get('/', function(req, res){
  res.send('Smart City using Data Mining web server is active.');
  console.log(req.query.id);
  var date = new Date();
  console.log("Request from client IP :" + req.ip + " on :" + date);//returns user's ip and date
});


//when the ip along with the port and '/Tube_associations' is appended
  app.get('/Tube_associations/', auth, function(req, res) {
	//save the query to a variable to use to query DB  
	var GridNoTemp = req.query.GridNo;
	Tube_associations.find({'GridNo': GridNoTemp}, 'Station', function (err, Tube_associations) {
		if (err){
		//	console.log(Tube_associations) // Space Ghost is a talk show host .
			res.send(Tube_associations);  
		}
		//console.log(Tube_associations) // Space Ghost is a talk show host .
		res.send(Tube_associations); 
		var date = new Date();
 console.log("Request from client IP :" + req.ip + " on :" + date);//returns user's ip and date 
	}) 
	
});

///returning everything in collection that has a GridNo
//when the ip along with the port and '/Tube_associations' is appended
  app.get('/Tube_associations_all/', auth, function(req, res) {
	Tube_associations.find({'GridNo': {$ne:null}}, 'GridNo Station', function (err, Tube_associations) {
		if (err){
		//	console.log(Tube_associations) // Space Ghost is a talk show host .
			res.send(Tube_associations);  
		}
		//console.log(Tube_associations) // Space Ghost is a talk show host . 
		res.send(Tube_associations);
		var date = new Date();
 console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
	
});



///NEW ONE TO RETURN PREDICTIONS AND HISTORY RETRIVAL FOR TUBE THEN ANOTHER FOR BIKE DATA/////////////////////////////////////////////////////////
//when the ip along with the port and '/Tube_associations' is appended
  app.get('/BoroughPopPredics', auth, function(req, res) {
	BoroughPopPredics.find({}, function (err, BoroughPopPredics) {
		if (err){}
		var fields1 = ['Borough','Year1','Year2','Year3','Year4','Year5','Year6','Year7','Year8','Year9','Year10','Year11','Year12','Year13','Year14','Year15','Year16','Year17','Year18','Year19','Year20','Year21','Year22','Year23','Year24','Year25','Year26','Year27','Year28','Year29','Year30','Year31','Year32'];
		json2csv({data: BoroughPopPredics, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});



//Returns BradfordStaticPop from MongoDB
  app.get('/BradfordStaticPop', auth, function(req, res) {
	BradfordStaticPop.find({}, function (err, BradfordStaticPop) {
		if (err){}
		var fields1 = ['CellID','Population', 'CellID Within Borough'];
		json2csv({data: BradfordStaticPop, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});

//Bradford_CellWorkPopulations
  app.get('/Bradford_CellWorkPopulations', auth, function(req, res) {
	Bradford_CellWorkPopulations.find({}, function (err, Bradford_CellWorkPopulations) {
		if (err){}
		var fields1 = ['CellID','Population', 'CellID Within Borough'];
		json2csv({data: Bradford_CellWorkPopulations, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});


//LiverpoolStaticPop
  app.get('/LiverpoolStaticPop', auth, function(req, res) {
	LiverpoolStaticPop.find({}, function (err, LiverpoolStaticPop) {
		if (err){}
		var fields1 = ['CellID','Population', 'CellID Within Borough'];
		json2csv({data: LiverpoolStaticPop, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});

//Liverpool_CellWorkPopulations
  app.get('/Liverpool_CellWorkPopulations', auth, function(req, res) {
	Liverpool_CellWorkPopulations.find({}, function (err, Liverpool_CellWorkPopulations) {
		if (err){}
		var fields1 = ['CellID','Population', 'CellID Within Borough'];
		json2csv({data: Liverpool_CellWorkPopulations, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});


//LondonStaticPop
  app.get('/LondonStaticPop', auth, function(req, res) {
	LondonStaticPop.find({}, function (err, LondonStaticPop) {
		if (err){}
		var fields1 = ['CellID','Population', 'CellID Within Borough'];
		json2csv({data: LondonStaticPop, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});

//London_CellWorkPopulations
  app.get('/London_CellWorkPopulations', auth, function(req, res) {
	London_CellWorkPopulations.find({}, function (err, London_CellWorkPopulations) {
		if (err){}
		var fields1 = ['CellID','Population', 'CellID Within Borough'];
		json2csv({data: London_CellWorkPopulations, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});


//WiganStaticPop
  app.get('/WiganStaticPop', auth, function(req, res) {
	WiganStaticPop.find({}, function (err, WiganStaticPop) {
		if (err){}
		var fields1 = ['CellID','Population', 'CellID Within Borough'];
		json2csv({data: WiganStaticPop, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});

//Wigan_CellWorkPopulations
  app.get('/Wigan_CellWorkPopulations', auth, function(req, res) {
	Wigan_CellWorkPopulations.find({}, function (err, Wigan_CellWorkPopulations) {
		if (err){}
		var fields1 = ['CellID','Population', 'CellID Within Borough'];
		json2csv({data: Wigan_CellWorkPopulations, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});
/////////////////////


//Tube_Grid_Predictions
  app.get('/WeekdayTubePredictions', auth, function(req, res) {
	//save the query to a variable to use to query DB  
	//var GridNoTemp = req.query.GridNo;
	//console.log(GridNoTemp); 
	WeekdayTubePredictions.find({}, function (err, WeekdayTubePredictions) {
		if (err){}
		var fields1 = ['1', 	'2', 	'3', 	'4', 	'5', 	'6', 	'7', 	'8', 	'9', 	'10', 	'11', 	'12', 	'13', 	'14', 	'15', 	'16', 	'17', 	'18', 	'19', 	'20', 	'21', 	'22', 	'23', 	'24', 	'25', 	'26', 	'27', 	'28', 	'29', 	'30', 	'31', 	'32', 	'33', 	'34', 	'35', 	'36', 	'37', 	'38', 	'39', 	'40', 	'41', 	'42', 	'43', 	'44', 	'45', 	'46', 	'47', 	'48', 	'49', 	'50', 	'51', 	'52', 	'53', 	'54', 	'55', 	'56', 	'57', 	'58', 	'59', 	'60', 	'61', 	'62', 	'63', 	'64', 	'65', 	'66', 	'67', 	'68', 	'69', 	'70', 	'71', 	'72', 	'73', 	'74', 	'75', 	'76', 	'77', 	'78', 	'79', 	'80', 	'81', 	'82', 	'83', 	'84', 	'85', 	'86', 	'87', 	'88', 	'89', 	'90', 	'91', 	'92', 	'93', 	'94', 	'95', 	'96', 	'97', 	'98', 	'99', 	'100', 	'101', 	'102', 	'103', 	'104', 	'105', 	'106', 	'107', 	'108', 	'109', 	'110', 	'111', 	'112', 	'113', 	'114', 	'115', 	'116', 	'117', 	'118', 	'119', 	'120', 	'121', 	'122', 	'123', 	'124', 	'125', 	'126', 	'127', 	'128', 	'129', 	'130', 	'131', 	'132', 	'133', 	'134', 	'135', 	'136', 	'137', 	'138', 	'139', 	'140', 	'141', 	'142', 	'143', 	'144', 	'145', 	'146', 	'147', 	'148', 	'149', 	'150', 	'151', 	'152', 	'153', 	'154', 	'155', 	'156', 	'157', 	'158', 	'159', 	'160', 	'161', 	'162', 	'163', 	'164', 	'165', 	'166', 	'167', 	'168', 	'169', 	'170', 	'171', 	'172', 	'173', 	'174', 	'175', 	'176', 	'177', 	'178', 	'179', 	'180', 	'181', 	'182', 	'183', 	'184', 	'185', 	'186', 	'187', 	'188', 	'189', 	'190', 	'191', 	'192', 	'193', 	'194', 	'195', 	'196', 	'197', 	'198', 	'199', 	'200', 	'201', 	'202', 	'203', 	'204', 	'205', 	'206', 	'207', 	'208', 	'209', 	'210', 	'211', 	'212', 	'213', 	'214', 	'215', 	'216', 	'217', 	'218', 	'219', 	'220', 	'221', 	'222', 	'223', 	'224', 	'225', 	'226', 	'227', 	'228', 	'229', 	'230', 	'231', 	'232', 	'233', 	'234', 	'235', 	'236', 	'237', 	'238', 	'239', 	'240', 	'241', 	'242', 	'243', 	'244', 	'245', 	'246', 	'247', 	'248', 	'249', 	'250', 	'251', 	'252', 	'253', 	'254', 	'255', 	'256', 	'257', 	'258', 	'259', 	'260', 	'261', 	'262', 	'263', 	'264', 	'265', 	'266'];
		json2csv({data: WeekdayTubePredictions, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});

//WeekendTubePredictions
  app.get('/WeekendTubePredictions', auth, function(req, res) {
	//save the query to a variable to use to query DB  
	//var GridNoTemp = req.query.GridNo;
	//console.log(GridNoTemp); 
	WeekendTubePredictions.find({}, function (err, WeekendTubePredictions) {
		if (err){}
		var fields1 = ['1', 	'2', 	'3', 	'4', 	'5', 	'6', 	'7', 	'8', 	'9', 	'10', 	'11', 	'12', 	'13', 	'14', 	'15', 	'16', 	'17', 	'18', 	'19', 	'20', 	'21', 	'22', 	'23', 	'24', 	'25', 	'26', 	'27', 	'28', 	'29', 	'30', 	'31', 	'32', 	'33', 	'34', 	'35', 	'36', 	'37', 	'38', 	'39', 	'40', 	'41', 	'42', 	'43', 	'44', 	'45', 	'46', 	'47', 	'48', 	'49', 	'50', 	'51', 	'52', 	'53', 	'54', 	'55', 	'56', 	'57', 	'58', 	'59', 	'60', 	'61', 	'62', 	'63', 	'64', 	'65', 	'66', 	'67', 	'68', 	'69', 	'70', 	'71', 	'72', 	'73', 	'74', 	'75', 	'76', 	'77', 	'78', 	'79', 	'80', 	'81', 	'82', 	'83', 	'84', 	'85', 	'86', 	'87', 	'88', 	'89', 	'90', 	'91', 	'92', 	'93', 	'94', 	'95', 	'96', 	'97', 	'98', 	'99', 	'100', 	'101', 	'102', 	'103', 	'104', 	'105', 	'106', 	'107', 	'108', 	'109', 	'110', 	'111', 	'112', 	'113', 	'114', 	'115', 	'116', 	'117', 	'118', 	'119', 	'120', 	'121', 	'122', 	'123', 	'124', 	'125', 	'126', 	'127', 	'128', 	'129', 	'130', 	'131', 	'132', 	'133', 	'134', 	'135', 	'136', 	'137', 	'138', 	'139', 	'140', 	'141', 	'142', 	'143', 	'144', 	'145', 	'146', 	'147', 	'148', 	'149', 	'150', 	'151', 	'152', 	'153', 	'154', 	'155', 	'156', 	'157', 	'158', 	'159', 	'160', 	'161', 	'162', 	'163', 	'164', 	'165', 	'166', 	'167', 	'168', 	'169', 	'170', 	'171', 	'172', 	'173', 	'174', 	'175', 	'176', 	'177', 	'178', 	'179', 	'180', 	'181', 	'182', 	'183', 	'184', 	'185', 	'186', 	'187', 	'188', 	'189', 	'190', 	'191', 	'192', 	'193', 	'194', 	'195', 	'196', 	'197', 	'198', 	'199', 	'200', 	'201', 	'202', 	'203', 	'204', 	'205', 	'206', 	'207', 	'208', 	'209', 	'210', 	'211', 	'212', 	'213', 	'214', 	'215', 	'216', 	'217', 	'218', 	'219', 	'220', 	'221', 	'222', 	'223', 	'224', 	'225', 	'226', 	'227', 	'228', 	'229', 	'230', 	'231', 	'232', 	'233', 	'234', 	'235', 	'236', 	'237', 	'238', 	'239', 	'240', 	'241', 	'242', 	'243', 	'244', 	'245', 	'246', 	'247', 	'248', 	'249', 	'250', 	'251', 	'252', 	'253', 	'254', 	'255', 	'256', 	'257', 	'258', 	'259', 	'260', 	'261', 	'262', 	'263', 	'264', 	'265', 	'266'];
		json2csv({data: WeekendTubePredictions, fields: fields1 }, function(err, csv) {
			if (err) throw err;
			res.send(csv);
		});	
		var date = new Date();
		console.log("Request from client IP at " + req.ip + " on " + date);//returns user's ip and date
	}) 
});


/// production error handler
// no stacktraces leaked to user  
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});

module.exports = app;
