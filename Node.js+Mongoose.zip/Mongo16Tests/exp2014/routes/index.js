var express = require('express');
var mongoose = require('mongoose');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var http = require('http');
var express = require('express');
var routes = require('./routes');
//var users = require('./routes/users');
console.log('running!');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hjs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//app.use('/', routes);
//app.use('/users', users);

// catch 404 and forward to error handler
//app.use(function(req, res, next) {
 // var err = new Error('Not Found');
 // err.status = 404;
 // next(err);
//});

// error handlers

// development error handler
// will print stacktrace 
//if (app.get('env') === 'development') {
 // app.use(function(err, req, res, next) {
//   res.status(err.status || 500);
//    res.render('error', {
 //     message: err.message,
      //error: err
    //});
  //});
//}
//mongoose.connect('mongodb://localhost/Smart_City');
mongoose.connect('mongodb://192.168.0.13/Smart_Cityasd')
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  // we're connected!
  console.log('hey!');
  
  var stationsSchema = mongoose.Schema({
    Station: String
});
  var Tube = mongoose.model('Tube', stationsSchema);
  
  Tube.find(function (err, Tube) {
  if (err) return console.error(err);
  console.log(Tube);
})

 
  app.get('/Tube_association', function(req, res) {
	mongoose.model('Tube_association').find(function(err, Tube_association){
		  console.log('hey!');
		res.send(Tube_association);
	});
});
  
});

schema = new mongoose.Schema({Station: 'string'});
 mongoose.model('Tube_association', schema,'Tube_association');

 //app.get('/', function(req, res) {
//	  res.send('ok'); 
 // });


 //app.get('/', function(req, res) {
//	  res.send('ok');
 // });

/// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});

module.exports = app;
