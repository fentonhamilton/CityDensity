var express = require('express');
var mongoose = require('mongoose');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var http = require('http');
var express = require('express');
//var routes = require('./routes');
//var users = require('./routes/users'); 
console.log('running!');
var app = express();

// view engine setup 
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hjs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico'))); 
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//app.use('/', routes);
//app.use('/users', users);

// catch 404 and forward to error handler
//app.use(function(req, res, next) {
 // var err = new Error('Not Found');
 // err.status = 404;
 // next(err);
//});

// error handlers

// development error handler
// will print stacktrace 
//if (app.get('env') === 'development') {
 // app.use(function(err, req, res, next) {
//   res.status(err.status || 500);
//    res.render('error', {
 //     message: err.message,
      //error: err
    //});
  //});
//}
//mongoose.connect('mongodb://localhost/Smart_City'); 
//next thing to try is just a query. the above might be like use db where 
//creates a new db if one is not there
mongoose.connect('mongodb://localhost/Smart_City');
 
var db = mongoose.connection;
 
db.on('error', function (err) {
console.log('connection error', err);
});
db.once('open', function () {
console.log('connected.');
});
 
var Schema = mongoose.Schema;
var userSchema = new Schema({
	GridNo : Number,
	Zone : Number,
	Station : String,
	Latitude : Number,
	Longtitude : Number
}, {collection:'Tube_associations'}); ///this fixed it. now to remove internal cache  
 //
 
var Tube_associations = mongoose.model('Tube_associations', userSchema, Tube_associations);
 /*
 Tube_associations.find({'GridNo': '1267'}, 'Station GridNo', function (err, Tube_associations) {
  if (err) return handleError(err);
  console.log(Tube_associations) // Space Ghost is a talk show host .
}) 
*/
/*
app.get('/', function(req,res) {
	console.log(req.query);
});
*/
//var GridNo = 1267;

///////////////////////////test//////////////////
app.use(function (req, res, next) {

    // Website you wish to allow to connect
        res.setHeader('Access-Control-Allow-Origin', '*');

//  // Request methods you wish to allow
//     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

//  // Request headers you wish to allow
//     res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

//     Set to true if you need the website to include cookies in the requests sent
//     to the API (e.g. in case you use sessions)
//     res.setHeader('Access-Control-Allow-Credentials', true);
    // Pass to next layer of middleware
    next();
});

////////////////////test////////////////////////////


app.get('/', function(req, res){
  res.send('Query it properly you idiot boy...');
  console.log(req.query.id);
});

  app.get('/Tube_associations/', function(req, res) {
	  
//	  res.send('GridNo: ' + req.query.GridNo);  
	var GridNoTemp = req.query.GridNo;
	console.log(GridNoTemp);
	Tube_associations.find({'GridNo': GridNoTemp}, 'Station', function (err, Tube_associations) {
	if (err){
	console.log(Tube_associations) // Space Ghost is a talk show host .
	res.send(Tube_associations);  
	}
	console.log(Tube_associations) // Space Ghost is a talk show host .
	res.send(Tube_associations); 
	}) 
	
	
	/*
	Tube_associations.find(function(err, Tube_associations){
		var GridNo = req.query.GridNo;
		console.log(GridNo);
		Tube_associations.find({'GridNo': GridNo}, 'Station GridNo', function (err, Tube_associations) {
		if (err) return handleError(err);
			console.log("hello") // Space Ghost is a talk show host .
			}) 
		//  res.send(Tube_associations);  
	});*/
	
});
//console.log(JSON.stringify(GridNo));
/*Tube_associations.find({'GridNo': GridNo}, 'Station GridNo', function (err, Tube_associations) {
		   if (err) return handleError(err);
		   console.log(Tube_associations) // Space Ghost is a talk show host .
		}) 

*/





/*mongoose.connect('mongodb://192.168.0.13/Smart_City')
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  // we're connected!
  console.log('hey!');
  
  var stationsSchema = mongoose.Schema({
    Station: String
});
  var Tube = mongoose.model('Tube', stationsSchema);
  
  Tube.find(function (err, Tube) {
  if (err) return console.error(err);
  var temp = Tube;
  var temp1 = temp.toString();
  console.log(temp1);
}) 

 

  
}); */

//schema = new mongoose.Schema({Station: 'string'});
 //mongoose.model('Tube_association', schema,'Tube_association');

 //app.get('/', function(req, res) {
//	  res.send('ok'); 
 // });


 //app.get('/', function(req, res) {
//	  res.send('ok');
 // });

/// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});

module.exports = app;
