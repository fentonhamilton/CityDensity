library(xlsx)
library(gdata)
setwd("C:\\Users\\Fenton\\Desktop\\University\\5. Fourth Year (MEng)\\Project\\second semester work\\Rtests")
tubeDataProcessing= read.csv("Nov09JnyExport.csv", colClasses=c(NA, "NULL",NA,NA,NA,NA,"NULL", NA, "NULL", "NULL", "NULL", "NULL","NULL", "NULL"))
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$SubSystem=="LTB"),] #removes buses
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$SubSystem=="TRAM"),] #removes TRAM
tubeDataProcessing<-tubeDataProcessing[-grep("\\/",tubeDataProcessing$SubSystem),] #removes combo journeys
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$SubSystem=="HEX"),] #REMOVES HEX
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$StartStn=="Unstarted"),] # removes unstarted
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$EndStation=="Unfinished"),] # removes unfinished
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$EndStation=="Not Applicable"),] # Not Applicable
tubeDataProcessing$EntTime <- round(tubeDataProcessing$EntTime/5)*5 #5 minute rounding(bins..yes?)
tubeDataProcessing$ExTime <- round(tubeDataProcessing$ExTime/5)*5 #5 minute rounding(bins..yes?)
plot(tubeDataProcessing$downo,which(tubeDataProcessing$EntTime&tubeDataProcessing$StartStn=="Euston"))
plot(which(tubeDataProcessing$StartStn=="Euston"))
tubeDataProcessing[(which(tubeDataProcessing$StartStn=="Euston")),6]
counts <- table(tubeDataProcessing[(which(tubeDataProcessing$StartStn=="Euston")),5])
plot(counts)
countAllEntries <- table(tubeDataProcessing[,5]/60)
barplot(countAllEntries)
countAllExits <- table(tubeDataProcessing[,6]/60)
barplot(countAllExits)