library(xlsx)
library(gdata)
library(tseries)
setwd("C:\\Users\\Fenton\\Desktop\\University\\5. Fourth Year (MEng)\\Project\\second semester work\\Rtests")
exits= read.csv("30 minute exits Pre-Processed.csv")
entries= read.csv("30 minute entries Pre-Processed.csv")
exits<-exits[!(exits$DAY=="1"),] #removes saturdays
entries<-entries[!(entries$DAY=="1"),] #removes saturdays
exits<-exits[!(exits$DAY=="7"),] #removes saturdays
entries<-entries[!(entries$DAY=="7"),] #removes saturdays
colnames(entries)[1] <- "NLC"
colnames(exits)[1] <- "NLC"
entries<-entries[!(entries$NLC!=500),] #removes all that are not nlc 500
exits<-exits[!(exits$NLC!=500),] #removes all that are not nlc 500


counts <- table(tubeDataProcessing[(which(tubeDataProcessing$StartStn=="Euston")),5])
plot(counts)
countAllEntries <- table(tubeDataProcessing[,5]/60)
barplot(countAllEntries)
countAllExits <- table(tubeDataProcessing[,6]/60)
barplot(countAllExits)

(tuberegres.ar <- ar(tubeDataProcessing$exits1_sum-tubeDataProcessing1$entries1_sum, aic=TRUE))
predict(tuberegres.ar, n.ahead = 25)
## try the other methods too

#predicts nicely @ 20 with unprocessed data
library(forecast)
sensor <- ts(tubeDataProcessing$exits1_sum,frequency=48) # consider adding a start so you get nicer labelling on your chart. 
fit <- auto.arima(sensor)
fcast <- forecast(fit)
plot(fcast)
grid()
fcast

acf(residuals(fit))

##dickey fuller test for stationarity
library(tseries)
adf.test(tubeDataProcessing$exits1_sum)

fit <- Arima(tubeDataProcessing$exits1_sum, order=c(3,0,1), seasonal=c(2,0,0), lambda=0)

#good function
plotForecastErrors <- function(forecasterrors)
{
  # make a histogram of the forecast errors:
  mybinsize <- IQR(forecasterrors)/4
  mysd   <- sd(forecasterrors)
  mymin  <- min(forecasterrors) - mysd*5
  mymax  <- max(forecasterrors) + mysd*3
  # generate normally distributed data with mean 0 and standard deviation mysd
  mynorm <- rnorm(10000, mean=0, sd=mysd)
  mymin2 <- min(mynorm)
  mymax2 <- max(mynorm)
  if (mymin2 < mymin) { mymin <- mymin2 }
  if (mymax2 > mymax) { mymax <- mymax2 }
  # make a red histogram of the forecast errors, with the normally distributed data overlaid:
  mybins <- seq(mymin, mymax, mybinsize)
  hist(forecasterrors, col="red", freq=FALSE, breaks=mybins)
  # freq=FALSE ensures the area under the histogram = 1
  # generate normally distributed data with mean 0 and standard deviation mysd
  myhist <- hist(mynorm, plot=FALSE, breaks=mybins)
  # plot the normal curve as a blue line on top of the histogram of forecast errors:
  points(myhist$mids, myhist$density, type="l", col="blue", lwd=2)
}



#timeseries weekday
entriestimeseries <- ts(entries$entries1_sum, frequency=48)

exitstimeseries <- ts(exits$exits1_sum, frequency=48)
exitstimeseriescomponents <- decompose(exitstimeseries)
exitstimeseriesseasonallyadjusted <- exitstimeseries - exitstimeseriescomponents$seasonal #seasonally adjusted 
#The seasonally adjusted time series now just contains the TREND component and an IRREGULAR component.
exitssertiesforecasts <- HoltWinters(exitstimeseries, beta=FALSE, gamma=FALSE) #forecast
exitssertiesforecasts$fitted #fittedline
exitssertiesforecasts$SSE #accuracy of the forecast
exitsseriesforecasts2 <- forecast.HoltWinters(exitsseriesforecasts, h=8)#forecast 8 ahead
plot.forecast(exitsseriesforecasts2)

#exponential smoothing
HWexitstimeseriesforecasts <- HoltWinters(exitstimeseries, beta=NULL)#beta stops trend
HWexitstimeseriesforecasts2 <- forecast.HoltWinters(HWexitstimeseriesforecasts, h=48)
plot(HWexitstimeseriesforecasts2)
acf(HWexitstimeseriesforecasts2$residuals, lag.max = 80)
Box.test(HWexitstimeseriesforecasts2$residuals, lag = 20, type="Ljung-Box")
plotForecastErrors(HWexitstimeseriesforecasts2$residuals)
acf(exitstimeseriescomponents$seasonal)
acf(exitstimeseriesseasonallyadjusted)
#new ARIMA model testing
library(forecast)
sensor <- exitstimeseries # consider adding a start so you get nicer labelling on your chart. 
fit <- auto.arima(sensor, trace = TRUE)
fcast <- forecast(fit)
plot(fcast)
grid()
fcast


#usinng exponential weekdays
tubeData= read.csv("TubeData_withSinkSource.csv")
tubeData<-tubeData[!(tubeData$DAY=="1"),]
tubeData<-tubeData[!(tubeData$DAY=="7"),]
#dealing with each station
tempNLC<- 0
tempStation<- 0
for(i in 1:dim(TubeData)[1]){
  if(tempNLC!=TubeData[i,1]){
    Station <- TubeData[i:(i+480),]#LOOOOOOOOK CHANGED TO 480 (NOT THAT IT WILL MAKE MUCH D)
    i=i+479
    tempNLC<-TubeData[i,1]
    #forecasting
    entriestimeseries <- ts(Station$entries1_sum, frequency=48)
    exitstimeseries <- ts(Station$exits1_sum, frequency=48)
    
    HWexitstimeseriesforecasts <- HoltWinters(exitstimeseries, beta=NULL)#beta stops trend
    HWexitstimeseriesforecasts2 <- forecast.HoltWinters(HWexitstimeseriesforecasts, h=48)
    predictionsexits <- as.numeric(HWexitstimeseriesforecasts2$mean)
    
    
    HWentriestimeseriesforecasts <- HoltWinters(entriestimeseries, beta=NULL)#beta stops trend
    HWentriestimeseriesforecasts2 <- forecast.HoltWinters(HWentriestimeseriesforecasts, h=48)
    predictionsentries <- as.numeric(HWentriestimeseriesforecasts2$mean)
    
    
    #  Station[433:480,]
    #  newPredictdf$exits1_sum<-round(HWexitstimeseriesforecasts2$mean)
    #  predictionsdf <- data.frame(predictionsexits, predictionsentries)
    
    newPredictdf<-Station[433:480,]
    newPredictdf$CALENDARDATE<-"new"
    newPredictdf$DAY<-"new"
    newPredictdf$exits1_sum<-round(predictionsexits)
    newPredictdf$entries1_sum<- round(predictionsentries)
    #need to calc last column exits - entries
    
    tempStation <-rbind(tempStation,Station)
    tempStation <-rbind(tempStation, newPredictdf)
    
    
  }
}
tempStation<-tempStation[-1,]
write.csv(tempStation, file="HistoricandPredictions.csv")
tempStation$Exits.Entries<-tempStation$exits1_sum-tempStation$entries1_sum
write.csv(tempStation, file="StationOutputTest1.csv")











#NOTE TO FIX THE FORMAT TO HAVE TUBE STATION AS THE HEADER
#SPLIT BY DATA INTO SEPARATE DF

#weekends

#usinng exponential WEEKENDS NEW WITH STLF/////////////////////////
tubeDataWknds= read.csv("TubeData_withSinkSource.csv")
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="2"),]
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="3"),]
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="4"),]
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="5"),]
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="6"),]
#dealing with each station
tempNLC<- 0
tempStation<- 0
for(i in 1:dim(tubeDataWknds)[1]){
  if(tempNLC!=tubeDataWknds[i,1]){
    Station <- tubeDataWknds[i:(i+191),]
    i=i+191
    tempNLC<-tubeDataWknds[i,1]
    #forecasting
    entriestimeseries <- ts(Station$entries1_sum, frequency=48)
    exitstimeseries <- ts(Station$exits1_sum, frequency=48)
    
    
    fitexits <- stlf(exitstimeseries)
    forecastexits <- forecast(fitexits)
    predictionsexits <- as.numeric(forecastexits$mean)
#  HWexitstimeseriesforecasts <- HoltWinters(exitstimeseries, beta=NULL)#beta stops trend
#  HWexitstimeseriesforecasts2 <- forecast.HoltWinters(HWexitstimeseriesforecasts, h=48)
#  predictionsexits <- as.numeric(HWexitstimeseriesforecasts2$mean)
    
    
 #   HWentriestimeseriesforecasts <- HoltWinters(entriestimeseries, beta=NULL)#beta stops trend
  #  HWentriestimeseriesforecasts2 <- forecast.HoltWinters(HWentriestimeseriesforecasts, h=48)
  #  predictionsentries <- as.numeric(HWentriestimeseriesforecasts2$mean)
    
    fitentries <- stlf(entriestimeseries, h=48)
    forecastentries <- forecast(fitentries)
    predictionsentries <- as.numeric(forecastentries$mean)
    
    
    
    
    newPredictdf<-Station[145:192,]
    newPredictdf$CALENDARDATE<-"new"
    newPredictdf$DAY<-"new"
    newPredictdf$exits1_sum<-round(predictionsexits[1:48])
    newPredictdf$entries1_sum<- round(predictionsentries[1:48])
    #need to calc last column exits - entries
    
    tempStation <-rbind(tempStation,Station)
    tempStation <-rbind(tempStation, newPredictdf)
    
    
  }
}
tempStation<-tempStation[-1,]
tempStation$Exits.Entries<-tempStation$exits1_sum-tempStation$entries1_sum
write.csv(tempStation, file="StationOutputWeekends.csv")





#weather
London_Rainfall= read.csv("London_Rainfall.csv")
London_Rainfall<-London_Rainfall[,-1]
y1<-London_Rainfall[1,]
y2<-London_Rainfall[2,]
y3<-London_Rainfall[3,]
y4<-London_Rainfall[4,]
y5<-London_Rainfall[5,]
y6<-London_Rainfall[6,]
plot(x, y1,type="l", col = "red",ylim=c(0,180),xlab="Month", ylab="Rainfall in a month (mm)")
lines(x,y2,col="green")
lines(x,y3,col="blue")
lines(x,y4,col="black")
lines(x,y5,col="yellow")
lines(x,y6,col="orange")
title(main="Monthly rainfall in London 2010-2015")
legend('topright', legend=c(2010,2011,2012,2013,2014,2015) , 
       lty=1, col=c('red', 'green', 'blue',' black', 'yellow', 'orange'), bty='n', cex=.75)

#sunshine
London_Sunshine= read.csv("London_Sunshine.csv")
London_Sunshine<-London_Sunshine[,-1]
y1<-London_Sunshine[1,]
y2<-London_Sunshine[2,]
y3<-London_Sunshine[3,]
y4<-London_Sunshine[4,]
y5<-London_Sunshine[5,]
y6<-London_Sunshine[6,]
plot(x, y1,type="l", col = "red", ylim=c(0,300),xlab="Month", ylab="Sunshine (hours)")
lines(x,y2,col="green")
lines(x,y3,col="blue")
lines(x,y4,col="black")
lines(x,y5,col="yellow")
lines(x,y6,col="orange")
title(main="Monthly Sunshine in London 2010-2015")
legend('topright', legend=c(2010,2011,2012,2013,2014,2015) , 
       lty=1, col=c('red', 'green', 'blue',' black', 'yellow', 'orange'), bty='n', cex=.75)