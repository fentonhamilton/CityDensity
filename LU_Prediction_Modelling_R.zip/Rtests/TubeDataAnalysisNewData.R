library(xlsx)
library(gdata)
library(tseries)
setwd("C:\\Users\\Fenton\\Desktop\\University\\5. Fourth Year (MEng)\\Project\\second semester work\\Rtests")
tubeDataProcessing= read.csv("TubeData_withSinkSource.csv")
tubeDataProcessing= read.csv("averagedvalues.csv", colClasses=c(NA, "NULL",NA,NA,NA,NA))
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$DAY=="1"),] #removes saturdays
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$DAY=="7"),] #removes sundays
colnames(tubeDataProcessing)[1] <- "NLC"
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$NLC!=500),] #removes all that are not nlc 500
#note it may be worth merging the exits and entries into one in the pre-processing program

#testing at the minute
y <- msts(entries$entries1_sum, seasonal.periods=c(7,365.25))
fit <- tbats(y)
fc <- forecast(fit)
plot(fc)

#doesnt work
library(forecast)
value <- c(1.2,1.7,1.6, 1.2, 1.6, 1.3, 1.5, 1.9, 5.4, 4.2, 5.5, 6.0, 5.6, 6.2, 6.8, 7.1, 7.1, 5.8, 0.0, 5.2, 4.6, 3.6, 3.0, 3.8, 3.1, 3.4, 2.0, 3.1, 3.2, 1.6, 0.6, 3.3, 4.9, 6.5, 5.3, 3.5, 5.3, 7.2, 7.4, 7.3, 7.2, 4.0, 6.1, 4.3, 4.0, 2.4, 0.4, 2.4, 1.2,1.7,1.6, 1.2, 1.6, 1.3, 1.5, 1.9, 5.4, 4.2, 5.5, 6.0, 5.6, 6.2, 6.8, 7.1, 7.1, 5.8, 0.0, 5.2, 4.6, 3.6, 3.0, 3.8, 3.1, 3.4, 2.0, 3.1, 3.2, 1.6, 0.6, 3.3, 4.9, 6.5, 5.3, 3.5, 5.3, 7.2, 7.4, 7.3, 7.2, 4.0, 6.1, 4.3, 4.0, 2.4, 0.4, 2.4)
sensor <- ts(value,frequency=24) # consider adding a start so you get nicer labelling on your chart. 
fit <- auto.arima(sensor)
fcast <- forecast(fit)
plot(fcast)
grid()
fcast

#
sensor2 <- runif(240)*sample(0:10, 240, replace = T) 
sensor2 <- ts(sensor2, freq = 24) 
fit2 <- auto.arima(sensor2) 
fcast2 <- forecast(fit2) 
plot(fcast2)



tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$SubSystem=="TRAM"),] #removes TRAM
tubeDataProcessing<-tubeDataProcessing[-grep("\\/",tubeDataProcessing$SubSystem),] #removes combo journeys
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$SubSystem=="HEX"),] #REMOVES HEX
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$StartStn=="Unstarted"),] # removes unstarted
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$EndStation=="Unfinished"),] # removes unfinished
tubeDataProcessing<-tubeDataProcessing[!(tubeDataProcessing$EndStation=="Not Applicable"),] # Not Applicable
tubeDataProcessing$EntTime <- round(tubeDataProcessing$EntTime/5)*5 #5 minute rounding(bins..yes?)
tubeDataProcessing$ExTime <- round(tubeDataProcessing$ExTime/5)*5 #5 minute rounding(bins..yes?)
plot(tubeDataProcessing$downo,which(tubeDataProcessing$EntTime&tubeDataProcessing$StartStn=="Euston"))
plot(which(tubeDataProcessing$StartStn=="Euston"))
tubeDataProcessing[(which(tubeDataProcessing$StartStn=="Euston")),6]
counts <- table(tubeDataProcessing[(which(tubeDataProcessing$StartStn=="Euston")),5])
plot(counts)
countAllEntries <- table(tubeDataProcessing[,5]/60)
barplot(countAllEntries)
countAllExits <- table(tubeDataProcessing[,6]/60)
barplot(countAllExits)

(tuberegres.ar <- ar(tubeDataProcessing$exits1_sum-tubeDataProcessing1$entries1_sum, aic=TRUE))
predict(tuberegres.ar, n.ahead = 25)
## try the other methods too

#predicts nicely @ 20 with unprocessed data
library(forecast)
sensor <- ts(tubeDataProcessing$exits1_sum,frequency=48) # consider adding a start so you get nicer labelling on your chart. 
fit <- auto.arima(sensor)
fcast <- forecast(fit)
plot(fcast)
grid()
fcast

acf(residuals(fit))

##dickey fuller test for stationarity
library(tseries)
adf.test(tubeDataProcessing$exits1_sum)

fit <- Arima(tubeDataProcessing$exits1_sum, order=c(3,0,1), seasonal=c(2,0,0), lambda=0)
