library(xlsx)
library(gdata)
library(tseries)
library(forecast)

#this file is testing the different models including Holt Winters,
#STLF and STLF with ARIMA modelling
#weekdays
tubeDataWd= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWd)[1] <- "NLC"
tubeDataWd<-tubeDataWd[!(tubeDataWd$NLC!=516),]
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="1"),] #removes sundays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="7"),] #removes saturdays
Station <- tubeDataWd
entriestimeseries <- ts(tubeDataWd$entries1_sum, frequency=48)
exitstimeseries <- ts(tubeDataWd$exits1_sum, frequency=48)

#EXITS
#HW Exponential smoothing
HWexitstimeseriesforecasts <- HoltWinters(exitstimeseries, beta=NULL)#beta stops trend
HWexitstimeseriesforecasts2 <- forecast.HoltWinters(HWexitstimeseriesforecasts, h=48)
plot(HWexitstimeseriesforecasts2)
accuracy(HWexitstimeseriesforecasts2)

#NON-ARIMA(CHECK WHICH IS DEFAULT) STLF
fitexits <- stlf(exitstimeseries, h=48)
stlfnon_ARIMAforecastexits <- forecast(fitexits)
plot(stlfnon_ARIMAforecastexits)
stlfnon_ARIMAforecastexits$model
accuracy(stlfnon_ARIMAforecastexits)

#ARIMA STLF
fitexits <- stlf(exitstimeseries, h=48, method="arima")
stlfARIMAforecastexits <- forecast(fitexits)
plot(stlfARIMAforecastexits)
stlfARIMAforecastexits$model
accuracy(stlfARIMAforecastexits)




#ENTRIES
#NON-ARIMA(CHECK WHICH IS DEFAULT) STLF
fitentries <- stlf(entriestimeseries, h=48)
stlfnon_ARIMAforecastentries <- forecast(fitentries)

#ARIMA STLF
fitentries <- stlf(entriestimeseries, h=48, method="arima")
stlfARIMAforecastentries <- forecast(fitentries)

#HW Exponential smoothing
HWentriestimeseriesforecasts <- HoltWinters(entriestimeseries, beta=NULL)#beta stops trend
HWentriestimeseriesforecasts2 <- forecast.HoltWinters(HWentriestimeseriesforecasts, h=48)



#WEEEEEEEKENDDDDDDDS
tubeDataWknds= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWknds)[1] <- "NLC"
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$NLC!=516),]
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="2"),] #removes monday
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="3"),] #removes tuesday
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="4"),] #removes wednesday
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="5"),] #removes thursday
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="6"),] #removes friday
Station <- tubeDataWknds
entriestimeseries <- ts(tubeDataWknds$entries1_sum, frequency=48)
exitstimeseries <- ts(tubeDataWknds$exits1_sum, frequency=48)

#EXITS
#HW Exponential smoothing
HWexitstimeseriesforecasts <- HoltWinters(exitstimeseries, beta=NULL)#beta stops trend
HWexitstimeseriesforecasts2 <- forecast.HoltWinters(HWexitstimeseriesforecasts, h=48)
plot(HWexitstimeseriesforecasts2)
accuracy(HWexitstimeseriesforecasts2)

#NON-ARIMA(CHECK WHICH IS DEFAULT) STLF
fitexits <- stlf(exitstimeseries, h=48)
stlfnon_ARIMAforecastexits <- forecast(fitexits)
plot(stlfnon_ARIMAforecastexits)
stlfnon_ARIMAforecastexits$model
accuracy(stlfnon_ARIMAforecastexits)

#ARIMA STLF
fitexits <- stlf(exitstimeseries, h=48, method="arima")
stlfARIMAforecastexits <- forecast(fitexits)
plot(stlfARIMAforecastexits)
stlfARIMAforecastexits$model
accuracy(stlfARIMAforecastexits)



#ENTRIES
#NON-ARIMA(CHECK WHICH IS DEFAULT) STLF
fitentries <- stlf(entriestimeseries, h=48)
stlfnon_ARIMAforecastentries <- forecast(fitentries)

#ARIMA STLF
fitentries <- stlf(entriestimeseries, h=48, method="arima")
stlfARIMAforecastentries <- forecast(fitentries)

#HW Exponential smoothing
HWentriestimeseriesforecasts <- HoltWinters(entriestimeseries, beta=NULL)#beta stops trend
HWentriestimeseriesforecasts2 <- forecast.HoltWinters(HWentriestimeseriesforecasts, h=48)