library(xlsx)
library(gdata)
library(tseries)
library(forecast)

tubeDataWd= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWd)[1] <- "NLC"
tubeDataWd<-tubeDataWd[!(tubeDataWd$NLC!=638),] #manor house
tubeDataWd<-tubeDataWd[(tubeDataWd$DAY=="2"),] #select monday
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE=="19102015"),] #removes saturdays
plot.ts(tubeDataWd$Exits.Entries, xlab="30 minute interval (24 hour)", ylab="Exit-Entries Passenger Count")
title(main="Manor House LU Sink/Source Reperesentation (1 Day)")

tubeDataWd= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWd)[1] <- "NLC"
tubeDataWd<-tubeDataWd[!(tubeDataWd$NLC!=516),] #manor house
tubeDataWd<-tubeDataWd[(tubeDataWd$DAY=="2"),] #select monday
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE=="19102015"),] #removes saturdays
plot.ts(tubeDataWd$Exits.Entries, xlab="30 minute interval (24 hour)", ylab="Exit-Entries Passenger Count")
title(main="Manor House Sink/Source Reperesentation (1 Day)")


#STL componentts

plot(tempstl, main="STL Components Barons Court LU")


#weekdays
tubeDataWd= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWd)[1] <- "NLC"
tubeDataWd<-tubeDataWd[!(tubeDataWd$NLC!=516),]
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="1"),] #removes sundays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="7"),] #removes saturdays
Station <- tubeDataWd
entriestimeseries <- ts(tubeDataWd$entries1_sum, frequency=48)
exitstimeseries <- ts(tubeDataWd$exits1_sum, frequency=48)

tempstl<-stl(exitstimeseries, s.window=48)

#STL componentts
plot(tempstl, main="STL Components Barons Court LU")

#ACF
acf((tempstl$time.series[, "remainder"]), lag.max=96,main="Autocorrelation Function (ACF) Barons Court LU STL Remainder")

#PACF
pacf((tempstl$time.series[, "remainder"]), lag.max=96,main="Partial Autocorrelation Function (PACF) Barons Court LU STL Remainder")