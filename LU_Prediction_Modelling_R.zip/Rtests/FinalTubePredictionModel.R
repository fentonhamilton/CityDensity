library(xlsx)
library(gdata)
library(forecast)
library(tseries)
setwd("C:\\Users\\Fenton\\Desktop\\University\\5. Fourth Year (MEng)\\Project\\second semester work\\Rtests")

##dickey fuller test for stationarity
#adf.test(tubeDataProcessing$exits1_sum)

#good function checking distribution of forecast errors
plotForecastErrors <- function(forecasterrors)
{
  # make a histogram of the forecast errors:
  mybinsize <- IQR(forecasterrors)/4
  mysd   <- sd(forecasterrors)
  mymin  <- min(forecasterrors) - mysd*5
  mymax  <- max(forecasterrors) + mysd*3
  # generate normally distributed data with mean 0 and standard deviation mysd
  mynorm <- rnorm(10000, mean=0, sd=mysd)
  mymin2 <- min(mynorm)
  mymax2 <- max(mynorm)
  if (mymin2 < mymin) { mymin <- mymin2 }
  if (mymax2 > mymax) { mymax <- mymax2 }
  # make a red histogram of the forecast errors, with the normally distributed data overlaid:
  mybins <- seq(mymin, mymax, mybinsize)
  hist(forecasterrors, col="red", freq=FALSE, breaks=mybins)
  # freq=FALSE ensures the area under the histogram = 1
  # generate normally distributed data with mean 0 and standard deviation mysd
  myhist <- hist(mynorm, plot=FALSE, breaks=mybins)
  # plot the normal curve as a blue line on top of the histogram of forecast errors:
  points(myhist$mids, myhist$density, type="l", col="blue", lwd=2)
}



#notes one data frequency=48 as 48 30 minute periods in one day (24 hours)
#Days of the week start from 1=Sunday, 2=Monday...to 7=Saturday
#WEEKDAYS using STLF ARIMA forecasting
tubeData= read.csv("TubeData_withSinkSource.csv") #import data
tubeData<-tubeData[!(tubeData$DAY=="1"),] #remove weekends
tubeData<-tubeData[!(tubeData$DAY=="7"),] #remove weekends
entriestimeseries <- ts(tubeData$entries1_sum, frequency=48) #create entries time series
exitstimeseries <- ts(tubeData$exits1_sum, frequency=48) #create exits time series
#dealing with each station in dataset
tempNLC<- 0
tempStation<- 0
for(i in 1:dim(TubeData)[1]){
  if(tempNLC!=TubeData[i,1]){
    Station <- TubeData[i:(i+479),]
    i=i+479
    tempNLC<-TubeData[i,1]
    #forecasting
    entriestimeseries <- ts(Station$entries1_sum, frequency=48)
    exitstimeseries <- ts(Station$exits1_sum, frequency=48)
    
    fitexits <- stlf(exitstimeseries, h=48, method="arima")
    forecastexits <- forecast(fitexits)
    predictionsexits <- as.numeric(forecastexits$mean)
    
    fitentries <- stlf(entriestimeseries, h=48, method="arima")
    forecastentries <- forecast(fitentries)
    predictionsentries <- as.numeric(forecastentries$mean)
    
    newPredictdf<-Station[433:480,]
    newPredictdf$CALENDARDATE<-"new"
    newPredictdf$DAY<-"new"
    newPredictdf$exits1_sum<-round(predictionsexits)
    newPredictdf$entries1_sum<- round(predictionsentries)
    #need to calc last column exits - entries
    
    tempStation <-rbind(tempStation,Station)
    tempStation <-rbind(tempStation, newPredictdf)
  }
}
tempStation<-tempStation[-1,]
tempStation$Exits.Entries<-tempStation$exits1_sum-tempStation$entries1_sum
write.csv(tempStation, file="WeekdayHistoryandPredictions.csv")



#WEEKENDS using STLF ARIMA forecasting
tubeDataWknds= read.csv("TubeData_withSinkSource.csv") #import data
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="2"),] #remove weekdays
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="3"),] #remove weekdays
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="4"),] #remove weekdays
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="5"),] #remove weekdays
tubeDataWknds<-tubeDataWknds[!(tubeDataWknds$DAY=="6"),] #remove weekdays
entriestimeseries <- ts(tubeData$entries1_sum, frequency=48) #create entries exits time series
exitstimeseries <- ts(tubeData$exits1_sum, frequency=48) #create exits time series
#dealing with each station in dataset
tempNLC<- 0
tempStation<- 0
for(i in 1:dim(tubeDataWknds)[1]){
  if(tempNLC!=tubeDataWknds[i,1]){
    Station <- tubeDataWknds[i:(i+191),]
    i=i+191
    tempNLC<-tubeDataWknds[i,1]
    #forecasting
    entriestimeseries <- ts(Station$entries1_sum, frequency=48)
    exitstimeseries <- ts(Station$exits1_sum, frequency=48)
    
    fitexits <- stlf(exitstimeseries)
    forecastexits <- forecast(fitexits, h=48, method="arima")
    predictionsexits <- as.numeric(forecastexits$mean)

    fitentries <- stlf(entriestimeseries, h=48, method="arima")
    forecastentries <- forecast(fitentries)
    predictionsentries <- as.numeric(forecastentries$mean)
    
    newPredictdf<-Station[145:192,]
    newPredictdf$CALENDARDATE<-"new"
    newPredictdf$DAY<-"new"
    newPredictdf$exits1_sum<-round(predictionsexits[1:48])
    newPredictdf$entries1_sum<- round(predictionsentries[1:48])
    #need to calc last column exits - entries
    
    tempStation <-rbind(tempStation,Station)
    tempStation <-rbind(tempStation, newPredictdf)
  }
}
tempStation<-tempStation[-1,]
#calculate column Exits-Entries
tempStation$Exits.Entries<-tempStation$exits1_sum-tempStation$entries1_sum
write.csv(tempStation, file="WeekendHistoryandPredictions.csv")