library(xlsx)
library(gdata)
library(tseries)

#Weather
#cross correlation with each of the time series of the cycle data
#the data is currently split into years, but can be combined into a 
#5-year time-series if required for correlation
X<-1:12
#London Rainfall (Heathrow Weather Station)
London_Rainfall= read.csv("London_Rainfall.csv")
London_Rainfall<-London_Rainfall[,-1]
y1<-London_Rainfall[1,]
y2<-London_Rainfall[2,]
y3<-London_Rainfall[3,]
y4<-London_Rainfall[4,]
y5<-London_Rainfall[5,]
y6<-London_Rainfall[6,]
plot(x, y1,type="l", col = "red",ylim=c(0,180),xlab="Month", ylab="Rainfall in a month (mm)")
lines(x,y2,col="green")
lines(x,y3,col="blue")
lines(x,y4,col="black")
lines(x,y5,col="yellow")
lines(x,y6,col="orange")
title(main="Monthly rainfall in London 2010-2015")
legend('topright', legend=c(2010,2011,2012,2013,2014,2015) , 
       lty=1, col=c('red', 'green', 'blue',' black', 'yellow', 'orange'), bty='n', cex=.75)

#Sunshine (Heathrow Weather Station)
London_Sunshine= read.csv("London_Sunshine.csv")
London_Sunshine<-London_Sunshine[,-1]
y1<-London_Sunshine[1,]
y2<-London_Sunshine[2,]
y3<-London_Sunshine[3,]
y4<-London_Sunshine[4,]
y5<-London_Sunshine[5,]
y6<-London_Sunshine[6,]
plot(x, y1,type="l", col = "red", ylim=c(0,300),xlab="Month", ylab="Sunshine (hours)")
lines(x,y2,col="green")
lines(x,y3,col="blue")
lines(x,y4,col="black")
lines(x,y5,col="yellow")
lines(x,y6,col="orange")
title(main="Monthly Sunshine in London 2010-2015")
legend('topright', legend=c(2010,2011,2012,2013,2014,2015) , 
       lty=1, col=c('red', 'green', 'blue',' black', 'yellow', 'orange'), bty='n', cex=.75)