library(xlsx)
library(gdata)
library(tseries)

tubeDataWd= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWd)[1] <- "NLC"
tubeDataWd<-tubeDataWd[!(tubeDataWd$NLC!=516),]
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="1"),] #removes sundays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="7"),] #removes saturdays
tubeDataWd2<-tubeDataWd[(tubeDataWd$CALENDARDATE =="19102015"),] #removes saturdays
tubeDataWd3<-tubeDataWd[(tubeDataWd$CALENDARDATE =="20102015"),] #removes saturdays
tubeDataWd4<-tubeDataWd[(tubeDataWd$CALENDARDATE =="21102015"),] #removes saturdays
tubeDataWd5<-tubeDataWd[(tubeDataWd$CALENDARDATE =="22102015"),] #removes saturdays
tubeDataWd6<-tubeDataWd[(tubeDataWd$CALENDARDATE =="23102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="19102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="20102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="21102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="22102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="23102015"),] #removes saturdays

x<-1:48
x<-(x*30)/60
y1<-tubeDataWd[(tubeDataWd$DAY=="2"),]$entries1_sum
y2<-tubeDataWd[(tubeDataWd$DAY=="3"),]$entries1_sum
y3<-tubeDataWd[(tubeDataWd$DAY=="4"),]$entries1_sum
y4<-tubeDataWd[(tubeDataWd$DAY=="5"),]$entries1_sum
y5<-tubeDataWd[(tubeDataWd$DAY=="6"),]$entries1_sum
y6<-tubeDataWd2[(tubeDataWd2$DAY=="2"),]$entries1_sum
y7<-tubeDataWd3[(tubeDataWd3$DAY=="3"),]$entries1_sum
y8<-tubeDataWd4[(tubeDataWd4$DAY=="4"),]$entries1_sum
y9<-tubeDataWd5[(tubeDataWd5$DAY=="5"),]$entries1_sum
y10<-tubeDataWd6[(tubeDataWd6$DAY=="6"),]$entries1_sum
y1<-abs(y1-y6)
y2<-abs(y2-y7)
y3<-abs(y3-y8)
y4<-abs(y4-y9)
y5<-abs(y5-y10)
plot(x, y1,type="l", col = "red",ylim=c(0,1350), xlab="Hour (24 hour)", ylab="Entry Passenger Count")
lines(x,y2,col="orange")
lines(x,y3,col="green")
lines(x,y4,col="lightskyblue")
lines(x,y5,col="plum2")

title(main="Barons Court LU Station Weekday Entry Absolute Difference (2 Weeks)")
legend('topright', legend=c("Monday","Tuesday","Wednesday","Thursday","Friday") , 
       lty=1, col=c('red', 'orange', 'green',' lightskyblue', 'plum2'), bty='n', cex=.75)

#could do variation, one minus other week



#weekend

tubeDataWd= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWd)[1] <- "NLC"
tubeDataWd<-tubeDataWd[!(tubeDataWd$NLC!=516),]
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="2"),] #removes sundays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="3"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="4"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="5"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="6"),] #removes saturdays
tubeDataWd1<-tubeDataWd[(tubeDataWd$CALENDARDATE =="18102015"),] #removes saturdays
tubeDataWd7<-tubeDataWd[(tubeDataWd$CALENDARDATE =="24102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="18102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="24102015"),] #removes saturdays

x<-1:48
x<-(x*30)/60
y1<-tubeDataWd[(tubeDataWd$DAY=="1"),]$entries1_sum
y2<-tubeDataWd[(tubeDataWd$DAY=="7"),]$entries1_sum 
y3<-tubeDataWd1[(tubeDataWd1$DAY=="1"),]$entries1_sum 
y4<-tubeDataWd7[(tubeDataWd7$DAY=="7"),]$entries1_sum 
plot(x, y1,type="l", col = "red",ylim=c(0,600), xlab="Hour (24 hour)", ylab="Entry Passenger Count")
lines(x,y2,col="orange")
lines(x,y3,col="green")
lines(x,y4,col="lightskyblue")
title(main="Barons Court LU Station Weekend Entry Variation (2 weeks)")
legend('topright', legend=c("Satruday","Sunday","Satruday1","Sunday1") , 
       lty=1, col=c('red', 'orange', 'green',' lightskyblue'), bty='n', cex=.75)








#EXITS

library(xlsx)
library(gdata)
library(tseries)

tubeDataWd= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWd)[1] <- "NLC"
tubeDataWd<-tubeDataWd[!(tubeDataWd$NLC!=516),]
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="1"),] #removes sundays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="7"),] #removes saturdays
tubeDataWd2<-tubeDataWd[(tubeDataWd$CALENDARDATE =="19102015"),] #removes saturdays
tubeDataWd3<-tubeDataWd[(tubeDataWd$CALENDARDATE =="20102015"),] #removes saturdays
tubeDataWd4<-tubeDataWd[(tubeDataWd$CALENDARDATE =="21102015"),] #removes saturdays
tubeDataWd5<-tubeDataWd[(tubeDataWd$CALENDARDATE =="22102015"),] #removes saturdays
tubeDataWd6<-tubeDataWd[(tubeDataWd$CALENDARDATE =="23102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="19102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="20102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="21102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="22102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="23102015"),] #removes saturdays

x<-1:48
x<-(x*30)/60
y1<-tubeDataWd[(tubeDataWd$DAY=="2"),]$exits1_sum
y2<-tubeDataWd[(tubeDataWd$DAY=="3"),]$exits1_sum
y3<-tubeDataWd[(tubeDataWd$DAY=="4"),]$exits1_sum
y4<-tubeDataWd[(tubeDataWd$DAY=="5"),]$exits1_sum
y5<-tubeDataWd[(tubeDataWd$DAY=="6"),]$exits1_sum
y6<-tubeDataWd2[(tubeDataWd2$DAY=="2"),]$exits1_sum
y7<-tubeDataWd3[(tubeDataWd3$DAY=="3"),]$exits1_sum
y8<-tubeDataWd4[(tubeDataWd4$DAY=="4"),]$exits1_sum
y9<-tubeDataWd5[(tubeDataWd5$DAY=="5"),]$exits1_sum
y10<-tubeDataWd6[(tubeDataWd6$DAY=="6"),]$exits1_sum
y1<-abs(y1-y6)
y2<-abs(y2-y7)
y3<-abs(y3-y8)
y4<-abs(y4-y9)
y5<-abs(y5-y10)
plot(x, y1,type="l", col = "red",ylim=c(0,1350), xlab="Hour (24 hour)", ylab="Exit Passenger Count")
lines(x,y2,col="orange")
lines(x,y3,col="green")
lines(x,y4,col="lightskyblue")
lines(x,y5,col="plum2")
title(main="Barons Court LU Station Weekday Exit Absolute Difference (2 Weeks)")
legend('topright', legend=c("Monday","Tuesday","Wednesday","Thursday","Friday") , 
       lty=1, col=c('red', 'orange', 'green',' lightskyblue', 'plum2'), bty='n', cex=.75)

#could do variation, one minus other week



#weekend

tubeDataWd= read.csv("TubeData_withSinkSource.csv")
colnames(tubeDataWd)[1] <- "NLC"
tubeDataWd<-tubeDataWd[!(tubeDataWd$NLC!=516),]
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="2"),] #removes sundays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="3"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="4"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="5"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$DAY=="6"),] #removes saturdays
tubeDataWd1<-tubeDataWd[(tubeDataWd$CALENDARDATE =="18102015"),] #removes saturdays
tubeDataWd7<-tubeDataWd[(tubeDataWd$CALENDARDATE =="24102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="18102015"),] #removes saturdays
tubeDataWd<-tubeDataWd[!(tubeDataWd$CALENDARDATE =="24102015"),] #removes saturdays

x<-1:48
x<-(x*30)/60
y1<-tubeDataWd[(tubeDataWd$DAY=="1"),]$exits1_sum
y2<-tubeDataWd[(tubeDataWd$DAY=="7"),]$exits1_sum 
y3<-tubeDataWd1[(tubeDataWd1$DAY=="1"),]$exits1_sum 
y4<-tubeDataWd7[(tubeDataWd7$DAY=="7"),]$exits1_sum 
y1<- abs(y1-y3)
y2<- abs(y2-y4)
plot(x, y1,type="l", col = "red",ylim=c(0,600), xlab="Hour (24 hour)", ylab="Exit Passenger Count")
lines(x,y2,col="orange")
title(main="Barons Court LU Station Weekend Exit Absolute Difference (2 Weeks)")
legend('topright', legend=c("Satruday","Sunday") , 
       lty=1, col=c('red', 'orange'), bty='n', cex=.75)